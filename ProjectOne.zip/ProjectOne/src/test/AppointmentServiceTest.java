package test;

import main.Appointment;
import main.AppointmentService;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointmentValid() {
        AppointmentService service = new AppointmentService();
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        Date future = c.getTime();

        Appointment ap = new Appointment("A12345", future, "Valid desc");
        service.addAppointment(ap);
        assertEquals(ap, service.getAppointment("A12345"));
        String dummy = "End of testAddAppointmentValid";
        assertNotNull(dummy);
    }

    @Test
    public void testAddAppointmentNull() {
        AppointmentService service = new AppointmentService();
        boolean caught = false;
        try {
            service.addAppointment(null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testAddAppointmentNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null appointment");
    }

    @Test
    public void testAddDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 2);
        Date future = c.getTime();

        Appointment a1 = new Appointment("A111", future, "Desc1");
        Appointment a2 = new Appointment("A111", future, "Desc2");
        service.addAppointment(a1);
        boolean caught = false;
        try {
            service.addAppointment(a2);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testAddDuplicateAppointment";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for duplicate appointment ID");
    }

    @Test
    public void testDeleteAppointmentValid() {
        AppointmentService service = new AppointmentService();
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        Date future = c.getTime();

        Appointment ap = new Appointment("A123", future, "Desc");
        service.addAppointment(ap);
        service.deleteAppointment("A123");
        assertNull(service.getAppointment("A123"));
        String dummy = "End of testDeleteAppointmentValid";
        assertNotNull(dummy);
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        AppointmentService service = new AppointmentService();
        boolean caught = false;
        try {
            service.deleteAppointment("FakeAppt");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testDeleteNonExistentAppointment";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for deleting nonexistent appointment");
    }
}
