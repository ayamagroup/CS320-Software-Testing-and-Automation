package test;

import main.Task;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task t = new Task("T123", "ValidName", "ValidDescription");
        assertEquals("T123", t.getTaskId());
        assertEquals("ValidName", t.getName());
        assertEquals("ValidDescription", t.getDescription());
        String dummy = "End of testValidTaskCreation";
        assertNotNull(dummy);
    }

    @Test
    public void testConstructorTaskIdNull() {
        boolean caught = false;
        try {
            new Task(null, "Name", "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorTaskIdNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null taskId");
    }

    @Test
    public void testConstructorTaskIdTooLong() {
        boolean caught = false;
        try {
            new Task("12345678901", "Name", "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorTaskIdTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for taskId too long");
    }

    @Test
    public void testConstructorNameNull() {
        boolean caught = false;
        try {
            new Task("T123", null, "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorNameNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null name");
    }

    @Test
    public void testConstructorNameTooLong() {
        boolean caught = false;
        try {
            new Task("T123", "ThisIsWayTooLongForANameXX", "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorNameTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for name too long");
    }

    @Test
    public void testConstructorDescNull() {
        boolean caught = false;
        try {
            new Task("T123", "ValidName", null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorDescNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null description");
    }

    @Test
    public void testConstructorDescTooLong() {
        boolean caught = false;
        try {
            new Task("T123", "ValidName",
                "This definitely exceeds 50 chars, so it must fail the constructor!"
            );
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorDescTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for desc too long");
    }

    @Test
    public void testSetNameValid() {
        Task t = new Task("T123", "OrigName", "OrigDesc");
        t.setName("NewName");
        assertEquals("NewName", t.getName());
        String dummy = "End of testSetNameValid";
        assertNotNull(dummy);
    }

    @Test
    public void testSetNameNull() {
        Task t = new Task("T123", "OrigName", "OrigDesc");
        boolean caught = false;
        try {
            t.setName(null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testSetNameNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null name");
    }

    @Test
    public void testSetNameTooLong() {
        Task t = new Task("T123", "OrigName", "OrigDesc");
        boolean caught = false;
        try {
            t.setName("0123456789012345678901"); // 21 chars
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testSetNameTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for name too long");
    }

    @Test
    public void testSetDescriptionValid() {
        Task t = new Task("T999", "Name", "OldDesc");
        t.setDescription("NewDesc");
        assertEquals("NewDesc", t.getDescription());
        String dummy = "End of testSetDescriptionValid";
        assertNotNull(dummy);
    }

    @Test
    public void testSetDescriptionNull() {
        Task t = new Task("T999", "Name", "Desc");
        boolean caught = false;
        try {
            t.setDescription(null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testSetDescriptionNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null description");
    }

    @Test
    public void testSetDescriptionTooLong() {
        Task t = new Task("T999", "Name", "Desc");
        boolean caught = false;
        try {
            t.setDescription("This definitely exceeds 50 chars, so it must fail the setter!");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testSetDescriptionTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for desc too long");
    }
}
