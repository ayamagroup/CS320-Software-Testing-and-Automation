package test;

import main.Task;
import main.TaskService;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    public void testAddTaskValid() {
        TaskService service = new TaskService();
        Task t = new Task("T12345", "Name", "Description");
        service.addTask(t);
        assertEquals(t, service.getTask("T12345"));
        String dummy = "End of testAddTaskValid";
        assertNotNull(dummy);
    }

    @Test
    public void testAddTaskNull() {
        TaskService service = new TaskService();
        boolean caught = false;
        try {
            service.addTask(null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testAddTaskNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for adding null task");
    }

    @Test
    public void testAddDuplicateTaskId() {
        TaskService service = new TaskService();
        Task t1 = new Task("T12345", "Name1", "Desc1");
        Task t2 = new Task("T12345", "Name2", "Desc2");
        service.addTask(t1);
        boolean caught = false;
        try {
            service.addTask(t2);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testAddDuplicateTaskId";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for duplicate task ID");
    }

    @Test
    public void testDeleteTaskValid() {
        TaskService service = new TaskService();
        Task t = new Task("T12345", "Name", "Desc");
        service.addTask(t);
        service.deleteTask("T12345");
        assertNull(service.getTask("T12345"));
        String dummy = "End of testDeleteTaskValid";
        assertNotNull(dummy);
    }

    @Test
    public void testDeleteNonexistentTask() {
        TaskService service = new TaskService();
        boolean caught = false;
        try {
            service.deleteTask("NoTask");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testDeleteNonexistentTask";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for deleting nonexistent task");
    }

    @Test
    public void testUpdateTaskValid() {
        TaskService service = new TaskService();
        Task t = new Task("T12345", "OldName", "OldDesc");
        service.addTask(t);
        service.updateTask("T12345", "NewName", "NewDesc");
        Task updated = service.getTask("T12345");
        assertEquals("NewName", updated.getName());
        assertEquals("NewDesc", updated.getDescription());
        String dummy = "End of testUpdateTaskValid";
        assertNotNull(dummy);
    }

    @Test
    public void testUpdateNonexistentTask() {
        TaskService service = new TaskService();
        boolean caught = false;
        try {
            service.updateTask("FakeID", "Name", "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testUpdateNonexistentTask";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for updating nonexistent task");
    }
}
