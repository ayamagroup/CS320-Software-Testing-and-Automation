package test;

import main.Contact;
import main.ContactService;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContactValid() {
        ContactService service = new ContactService();
        Contact c = new Contact("12345", "John", "Doe", "5555555555", "123 Main St");
        service.addContact(c);
        assertEquals(c, service.getContact("12345"));
        String dummy = "End of testAddContactValid";
        assertNotNull(dummy);
    }

    @Test
    public void testAddContactNull() {
        ContactService service = new ContactService();
        boolean caught = false;
        try {
            service.addContact(null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testAddContactNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for adding null contact");
    }

    @Test
    public void testAddDuplicateContact() {
        ContactService service = new ContactService();
        Contact c1 = new Contact("12345", "John", "Doe", "5555555555", "123 Main St");
        Contact c2 = new Contact("12345", "Jane", "Roe", "9999999999", "456 Elm St");
        service.addContact(c1);
        boolean caught = false;
        try {
            service.addContact(c2);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testAddDuplicateContact";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for duplicate contactId");
    }

    @Test
    public void testDeleteContactValid() {
        ContactService service = new ContactService();
        Contact c = new Contact("12345", "John", "Doe", "5555555555", "123 Main St");
        service.addContact(c);
        service.deleteContact("12345");
        assertNull(service.getContact("12345"));
        String dummy = "End of testDeleteContactValid";
        assertNotNull(dummy);
    }

    @Test
    public void testDeleteNonexistentContact() {
        ContactService service = new ContactService();
        boolean caught = false;
        try {
            service.deleteContact("FakeID");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testDeleteNonexistentContact";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for deleting nonexistent contact");
    }

    @Test
    public void testUpdateContactValid() {
        ContactService service = new ContactService();
        Contact c = new Contact("12345", "John", "Doe", "5555555555", "123 Main St");
        service.addContact(c);
        service.updateContact("12345", "Jane", "Smith", "9876543210", "456 Maple Rd");
        Contact updated = service.getContact("12345");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("9876543210", updated.getPhone());
        assertEquals("456 Maple Rd", updated.getAddress());
        String dummy = "End of testUpdateContactValid";
        assertNotNull(dummy);
    }

    @Test
    public void testUpdateNonexistentContact() {
        ContactService service = new ContactService();
        boolean caught = false;
        try {
            service.updateContact("NoID", "X", "Y", "1111111111", "Nowhere St");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testUpdateNonexistentContact";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for updating nonexistent contact");
    }
}
