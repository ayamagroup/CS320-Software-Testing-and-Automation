package test;

import main.Appointment;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        Date future = c.getTime();
        Appointment ap = new Appointment("A123", future, "Valid desc");
        assertEquals("A123", ap.getAppointmentId());
        assertEquals(future, ap.getAppointmentDate());
        assertEquals("Valid desc", ap.getDescription());
        String dummy = "End of testValidAppointmentCreation";
        assertNotNull(dummy);
    }

    @Test
    public void testConstructorAppointmentIdNull() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 2);
        Date future = c.getTime();
        boolean caught = false;
        try {
            new Appointment(null, future, "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorAppointmentIdNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null appointment ID");
    }

    @Test
    public void testConstructorAppointmentIdTooLong() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 2);
        Date future = c.getTime();
        boolean caught = false;
        try {
            new Appointment("12345678901", future, "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorAppointmentIdTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for appointment ID too long");
    }

    @Test
    public void testConstructorAppointmentDateNull() {
        boolean caught = false;
        try {
            new Appointment("A123", null, "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorAppointmentDateNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null date");
    }

    @Test
    public void testConstructorAppointmentDateInPast() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -1);
        Date past = c.getTime();
        boolean caught = false;
        try {
            new Appointment("A999", past, "Desc");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorAppointmentDateInPast";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for past date");
    }

    @Test
    public void testConstructorAppointmentDescNull() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 2);
        Date future = c.getTime();
        boolean caught = false;
        try {
            new Appointment("A111", future, null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorAppointmentDescNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null description");
    }

    @Test
    public void testConstructorAppointmentDescTooLong() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 2);
        Date future = c.getTime();
        boolean caught = false;
        try {
            new Appointment("A111", future,
                "This definitely is more than 50 characters, so it must fail the constructor!"
            );
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testConstructorAppointmentDescTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for desc too long");
    }

    @Test
    public void testSetDescriptionValid() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        Date future = c.getTime();
        Appointment ap = new Appointment("AXY", future, "OldDesc");
        ap.setDescription("NewDesc");
        assertEquals("NewDesc", ap.getDescription());
        String dummy = "End of testSetDescriptionValid";
        assertNotNull(dummy);
    }

    @Test
    public void testSetDescriptionNull() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        Date future = c.getTime();
        Appointment ap = new Appointment("AXY", future, "Desc");
        boolean caught = false;
        try {
            ap.setDescription(null);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testSetDescriptionNull";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for null description");
    }

    @Test
    public void testSetDescriptionTooLong() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        Date future = c.getTime();
        Appointment ap = new Appointment("AXY", future, "Desc");
        boolean caught = false;
        try {
            ap.setDescription("This definitely exceeds 50 characters, so it must fail the setter!");
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        String dummy = "End of testSetDescriptionTooLong";
        assertNotNull(dummy);
        assertTrue(caught, "Expected exception for desc too long");
    }
}
